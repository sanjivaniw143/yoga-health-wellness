<div class="header">
	<div class="container" >
		<div class="row no-gutters align-items-center">
			<div class="col-md-4 col-7">
				<div class="head-call">
				
				</div>
			</div>
			<div class="col-md-8 col-5" style="    border-bottom: dashed 1px white;">
				<div class="head-call social-icons">
						<div class="call-icon">
						<i class="fas fa-phone-alt"></i>
						<p class=" d-inline-block text-white">+91 720 800 9584</p>
					</div> 
					<div class="call-icon">
						<a href="javascript:void(0);"><i class="fab fa-facebook"></i></a>
					</div>

					<div class="call-icon">
						<a href="javascript:void(0);"><i class="fab fa-twitter"></i></a>
					</div>

					<div class="call-icon">
						<a href="javascript:void(0);"><i class="fab fa-linkedin"></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<nav class="navbar navbar-expand-md">
	<div class="container">
		<a class="navbar-brand" href="https://www.matoshreelaparoscopycentre.com/"><h2 class="f700 text-white pb-0" style="font-size: 30px;">DRISHYAM</h2>
          <p class="f700 text-white" style="    font-size: 19px;
    ">CT SCAN CENTER</p></a>
          
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="fas fa-bars"></span>
	  </button>

	  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	    <ul class="navbar-nav ml-auto">
	      <li class="nav-item active">
	        <a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="team.php">About Us</a>
	      </li>
	    <!--   <li class="nav-item dropdown">
	        <a class="nav-link dropdown-toggle" href="javascript:void(0);" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
	          About Doctor
	        </a>
	        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
	          <a class="dropdown-item" href="about.php">About Doctor</a>
	          <a class="dropdown-item" href="profile.php">Academic Profile</a>
	          <a class="dropdown-item" href="Publications.php">Publications</a>
	          <a class="dropdown-item" href="papers-and-posters.php">Papers and Posters in CSI</a>
	          <a class="dropdown-item" href="experience.php">Experience</a>
	        </div>
	      </li> -->
	    
	     
	      <li class="nav-item">
	        <a class="nav-link" href="services.php">CT Scan Services</a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="index.php">Blog</a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="testimonials.php">Testimonials</a>
	      </li>
	       <li class="nav-item">
	        <a class="nav-link" href="contact.php">Contact</a>
	      </li>
	    </ul>
	  </div>
	</div>
</nav>