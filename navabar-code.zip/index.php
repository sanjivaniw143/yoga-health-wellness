<?php $title="DRISHYAM ct scan center" ?>
<?php include'includes/head.php';?>
<?php include'includes/menu.php';?>
<div id="demo" class="carousel slide" data-ride="carousel">

  <!-- Indicators -->
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  
  <!-- The slideshow -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/ct-scan.jpg" alt="" >
    </div>
   <!--  <div class="carousel-item">
      <img src="images/2.jpg" alt="" >
    </div>
    <div class="carousel-item">
      <img src="images/3.jpg" alt="" >
    </div> -->
  </div>
  
  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
 
<section>
  <div class="container">
     <div class="section-title clearfix">
                                <div class="title-header">
                                    <h5>  About Us</h5>
                                    <h2 class="title">Welcome to Drishyam ct scan center</h2>
                                </div>
                            </div><!-- section title end -->
    <div class="row">
    
     <div class="col-md-6 mt-5">
       <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
       <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using </p>
     </div>
      <div class="col-md-6 mt-3">
       <img src="images/about.png">
     </div>
    </div>
  </div>
</section>

<section style="background: lightgray;">
  <div class="container">

    <div class="row">
      <div class="col-md-6 ">
         <img src="images/service-bg.png">
      </div>
      <div class="col-md-6">
        <div class="section-title clearfix pb-5 mb-5">
                                <div class="title-header">
                                    <h5>  Services</h5>
                                    <h2 class="title">Our CT Scan Services</h2>
                                </div>
                            </div><!-- section title end -->
<ul class="list-unstyled inner-list2 pt-3">
<li class="list"><a class="dropdown-item " href="" style="border-top: 1px dotted #213d6c;">Brain and vessels</a></li>
<li class="list"><a class="dropdown-item " href="">Spine & joint</a></li>
<li class="list"><a class="dropdown-item " href="">Internal organs</a></li>
<li class="list"><a class="dropdown-item " href="">Mammary gland</a></li>
</ul>
                           <!--  <h2></i>Brain and vessels</h2>
                            <h2></i>Brain and vessels</h2>
                            <h2></i>Brain and vessels</h2>
                            <h2></i>Brain and vessels</h2> -->
      </div>
    </div>
  </div>
</section>

<section>
  <div class="container">
      <div class="section-title clearfix pb-5 mb-5">
                                <div class="title-header">
                                    <h5>  Reviews</h5>
                                    <h2 class="title">What our Patient Says!</h2>
                                </div>
                            </div><!-- section title end -->
    <div class="row">
      <div class="col-md-12 ">
                    
            <div class="testimonial-bg text-center">
                    <img src="images/testimonial-img.png">
                <div id="testimonial-slider" class="owl-carousel col-md-12">
                    <div class="testimonial pt-4">
 <i class="fa fa-star color-yellow"></i>
<i class="fa fa-star color-yellow"></i> <i class="fa fa-star color-yellow"></i>
<i class="fa fa-star color-yellow"></i> <i class="fa fa-star color-yellow"></i></i>
                        <p class="description">

                      Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                        </p>
                       
                        <h3 class="title pt-4">-Rahul Shah</h3>
                       
                    </div>
 
                       
                    </div>
                </div>
             
            </div>
    </div>
  </div>
</section>

<section style="background: url(images/BG.jpg) no-repeat;
    background-size: 100%;
        height: 495px;
    " class=" contact">
   <div class="container" style="
   
    height: 434px;
    border: 17px solid rgb(255, 255, 255);
    box-shadow: rgb(93 88 82 / 30%) 3px 3px 7px;">
          <div class="row">
              <div class="col-md-5 " style="background-color: #d1faffb0;height: 400px;">
                  <div class="container pt-20">
                      <div class="row">
                         <div class="section-title clearfix pb-5 mb-5">
                                <div class="title-header">
                                    <h5>  Contact </h5>
                                    <h2 class="title">Find us on Map</h2>
                                </div>
                            </div><!-- section title end -->
                          
                          <div class="col-md-12 ">
                               <p class="text-black f14 "><i class="fa fa-phone text-white"></i><a href="tel:+919920266062" class="text-black"> +91 720 800 9584</a></p>
               <p class="text-black f14 "><i class="fa fa-envelope text-white"></i><a href="#" class="text-black">info@gmail.com</a></p>
                              <p class="text-black f14 "><i class="fa fa-map-marker text-white"></i><b>Drishyam CT Scan Center-</b><br> Shanti Apartment, Shop No. 16, F-Type Building, Sector 11, Behind Taxi Stand / Nerul Bus Depo, Nerul, Navi Mumbai - 400706
</p>
              
             
                          </div>
                         
                      </div>
                  </div>
              </div>
              <div class="col-md-7 p-0">
                 <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3771.577672666322!2d73.01736801538391!3d19.0383227581019!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c3c2ff270de7%3A0x7163e943126b8b70!2sShanti%20Apartment!5e0!3m2!1sen!2sin!4v1624431387239!5m2!1sen!2sin" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                
              </div>
              
          </div>
</section>

<section class="footer ">
    <div class="container text-center">
    
    <div class="icon-social">
        <h2 class="f500 text-uppercase">Be Social</h2>
        <a href="" target="_blank"><i class="fab fa-facebook-f"></i></a>
        <a href="" target="_blank"><i class="fab fa-instagram"></i></a>
        <a href="" target="_blank"><i class="fab fa-twitter" target="_blank"></i></a>
        <a href="" target="_blank"><i class="fab fa-linkedin-in"></i></a>
        <a href="" target="_blank"><i class="fab fa-youtube"></i></a>
      </div>
      <div class="footer-links">
        <ul class="list-unstyled">
          <li class="d-inline-block"><a href="">Home</a> |</li>
          <li class="d-inline-block"><a href="">About Us</a> |</li>
          <li class="d-inline-block"><a href="">CT Scan Services</a> |</li>
         
          <li class="d-inline-block"><a href="">Gallery</a> |</li>
        
          <li class="d-inline-block"><a href="">Contact Us</a> </li>
        </ul>
      </div>
      <div class="copyright-content">
        <div class="container text-center">
          <p  class="text-white">Copyright &copy; <script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> All Rights Reserved, <span class="d-inline-block">By Drishyam CT Scan Center</span></p>
        </div>
      </div>
    </div>
  </section>
<div class="navbar-fixed-bottom d-lg-none d-xl-none d-md-none d-sm-none col-xs-12 " style="width:100%;text-align: center;position: fixed;right: 0;bottom: 0;left: 0;padding: 4px;background-color:lightgray;text-align: center;z-index:29">
<div class="d-lg-none d-xl-none d-md-none d-sm-none col-xs-12" style="background-color:#018F99;margin-top: 6px;padding:8px;  ">
<a href="tel:91 7208009584" style="color:white;">
<img src="images/phone-icon.png" style="    width: 32px;" alt="Call"> Call For Appointment</a>
</div>
</div>
 <script src="js/jquery-3.3.1.slim.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <!-- <script src="https://kit.fontawesome.com/2afb0dc715.js" crossorigin="anonymous"></script> -->
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/script.js"></script>
  
</body>
</html>
